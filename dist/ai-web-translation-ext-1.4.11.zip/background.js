/* 后台：代 content script 发跨域请求。只有这一件事，保持最小攻击面。 */
chrome.runtime.onMessage.addListener(function (msg, sender, respond) {
  if (!msg || msg.type !== 'xhr') return;

  var o = msg.opts || {};
  var ctrl = new AbortController();
  var timer = setTimeout(function () { ctrl.abort(); }, Math.max(3000, o.timeout || 12000));

  var init = {
    method: o.method || 'GET',
    headers: o.headers || {},
    signal: ctrl.signal,
    credentials: 'omit',
    redirect: 'follow',
    cache: 'no-store'
  };
  if (init.method !== 'GET' && init.method !== 'HEAD' && o.data !== null) init.body = o.data;

  fetch(o.url, init).then(function (r) {
    return r.text().then(function (t) {
      respond({ status: r.status, statusText: r.statusText, text: t });
    });
  }).catch(function (e) {
    respond({
      error: (e && e.name === 'AbortError')
        ? '请求超时（' + (o.url || '').slice(0, 60) + '）'
        : String((e && e.message) || e)
    });
  }).finally(function () { clearTimeout(timer); });

  return true;   /* 异步 respond */
});
