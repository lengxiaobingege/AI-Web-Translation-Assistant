/* 菜单入口：扩展没有 Tampermonkey 那种图标菜单，改用弹窗调起页面里的命令 */
const VERSION = '1.4.11';

function el(tag, cls) {
  const d = document.createElement(tag);
  if (cls) d.className = cls;
  return d;
}

function showEmpty(html) {
  const box = document.getElementById('list');
  box.innerHTML = '';
  const d = el('div', 'empty');
  d.innerHTML = html;
  box.appendChild(d);
}

function render(labels, tabId) {
  const box = document.getElementById('list');
  box.innerHTML = '';
  labels.forEach((label) => {
    const b = el('button', 'cmd');
    b.type = 'button';
    b.innerHTML = '<b></b>';
    b.querySelector('b').textContent = label;
    b.addEventListener('click', () => {
      chrome.tabs.sendMessage(tabId, { type: 'menuRun', label }, () => {
        void chrome.runtime.lastError;
        window.close();
      });
    });
    box.appendChild(b);
  });
}

async function init() {
  document.getElementById('ver').textContent = 'v' + VERSION;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return showEmpty('无法读取当前标签页。');

  chrome.tabs.sendMessage(tab.id, { type: 'menuList' }, (labels) => {
    if (chrome.runtime.lastError || !labels || !labels.length) {
      showEmpty('当前页面不可用。<br>浏览器内置页（chrome://、扩展商店等）不允许注入脚本，换一个普通网页再试。');
      return;
    }
    render(labels, tab.id);
  });
}

init();
